import{p as s}from"./DnDNma6u.js";const t=s("/assets/logo.svg");export{t as _};
