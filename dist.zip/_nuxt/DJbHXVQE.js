import{I as a,q as r,B as i}from"./DnDNma6u.js";const n=a((e,o)=>{const t=r();if(t.init(),!t.isAuthenticated)return i({path:"/login",query:{redirect:e.fullPath}})});export{n as default};
