import{J as a,q as r,B as i}from"./D9WcfMQ5.js";const n=a((e,o)=>{const t=r();if(t.init(),!t.isAuthenticated)return i({path:"/login",query:{redirect:e.fullPath}})});export{n as default};
