import{p as s}from"./D9WcfMQ5.js";const t=s("/assets/logo.svg");export{t as _};
